diccionario = {
    "nombre":"Paco",
    "apellido1":"Perez",
    "apellido2":"Bravo"
}



print("diccionario:", diccionario)
print("diccionario:", diccionario["nombre"])
print("diccionario:", diccionario["apellido1"])
print("diccionario:", diccionario["apellido2"])

diccionario["Nuevo atributo"] = "Paco vive en Mallorca"


print("actualizado el diccionario", diccionario)