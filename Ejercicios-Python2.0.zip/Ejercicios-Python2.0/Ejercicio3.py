# Crear un fichero

fichero_craedo = open("fichero-craedo.txt","w")
fichero_craedo.write("Creado correctamente")
print("Un ejercio menos ya el fichero esta creado con el nombre fichero-craedo")