#Leer el contenido de un fichero.

ruta = open('gg.txt')
print(ruta.read())

